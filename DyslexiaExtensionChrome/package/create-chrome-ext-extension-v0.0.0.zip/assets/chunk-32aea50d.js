console.info("chrome-ext template-react-js content script");
